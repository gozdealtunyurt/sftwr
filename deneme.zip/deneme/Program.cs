﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace deneme
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bilgiler bilgiler1 = new bilgiler();
            bilgiler1.ogrenciad = "Gözde";
            bilgiler1.ogrencisoayd = "ALTUNYURT";
            bilgiler1.ogrenciyas = 20;
            bilgiler1.ogrencisira = 15;
            bilgiler1.ogrencibolum = "yazılım mühendisliği";

            bilgiler1.ogrenciadresleri[0] = new adresler()
            {
                ogrenciodano = 205,
                ogrenciyatak = 6,
                ogrenciyurtadi = "Fatma Ana",
                ogrenciyurtkat = 1,
                ogrenciblok='B'
            };
            bilgiler1.ogrenciİletisimler[0] = new iletisimler()
            {
                ogrencitel = 123,
                ogrenciannetel = 1234,
                ogrencibabatel = 12345,
                ogrenciteltür = "ceptel"
            };
            Console.WriteLine("Öğrenci kişisel bilgiler");
            Console.WriteLine(bilgiler1.ogrenciad);
            Console.WriteLine(bilgiler1.ogrencisoayd);
            Console.WriteLine(bilgiler1.ogrenciyas);
            Console.WriteLine(bilgiler1.ogrencisira);
            Console.WriteLine(bilgiler1.ogrencibolum);
            Console.WriteLine("*****************************************");
            
            foreach(var içine in bilgiler1.ogrenciİletisimler)
            {
                Console.WriteLine(içine);
            }
            foreach(var içine1 in bilgiler1.ogrenciadresleri)
            {
                Console.WriteLine(içine1);
            }

            Console.ReadLine();
        }  
    }
}
