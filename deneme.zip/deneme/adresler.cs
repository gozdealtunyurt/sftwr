﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace deneme
{
    public class adresler
    {
        public int ogrenciodano;
        public int ogrenciyatak;
        public string ogrenciyurtadi;
        public int ogrenciyurtkat;
        public char ogrenciblok; 

        //public void yazdıradres()
        //
         //   Console.WriteLine("Öğrenci adres bilgileri");
        //}
    }
    
}
