﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace deneme
{
    public class bilgiler
    {
        public int ogrenciyas;
        public string ogrenciad;
        public string ogrencisoayd;
        public int ogrencisira;
        public string ogrencibolum;

        public adresler[] ogrenciadresleri;
        public iletisimler[] ogrenciİletisimler;
        public bilgiler()
        {
            ogrenciadresleri=new adresler[5];
            ogrenciİletisimler = new iletisimler[5];
        }

        

    }
}
