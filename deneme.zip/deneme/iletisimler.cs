﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace deneme
{
    public class iletisimler
    {
        public int ogrencitel;
        public int ogrenciannetel;
        public int ogrencibabatel;
        public string ogrenciteltür;

        // public void yazdıriletisim()
        // {
        //     Console.WriteLine("Öğregnci iletişim bilgileri");
        // }
        public override string ToString()
        {
            return "Telefon: " + ogrencitel + ", Anne Telefon: " + ogrenciannetel + ", Baba Telefon: " + ogrencibabatel + ", Tür: " + ogrenciteltür;
        }
    }
}
