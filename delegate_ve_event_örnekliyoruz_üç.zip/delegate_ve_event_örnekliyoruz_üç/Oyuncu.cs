﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace delegate_ve_event_örnekliyoruz_üç
{
    public class Oyuncu
    {
        private int _can;
        public int can
        {
            get { return _can; }
            set { _can = value; }
        }
        public Oyuncu(int canMiktari)
        {
            _can = canMiktari;
        }
        public delegate void OyuncuDelegate(int kalancan);
        public event OyuncuDelegate OyuncuEvent;

        public void Dovus()
        {
            can = can - 10;
            Console.WriteLine("can miktari: " + can);
            if (can <= 40)
                OyuncuEvent(can);
        }
    }
}   