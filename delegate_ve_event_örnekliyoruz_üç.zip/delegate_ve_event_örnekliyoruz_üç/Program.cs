﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace delegate_ve_event_örnekliyoruz_üç
{
    public class Program
    {
        static void Main(string[] args)
        {
            Oyuncu o =new Oyuncu(80);
            
            o.OyuncuEvent += Uyari;
            o.OyuncuEvent += Alarm;
           

            o.Dovus();
            o.Dovus();
            o.Dovus();
            o.Dovus();
            o.Dovus();
            o.Dovus();
            o.Dovus();
            Console.ReadLine();
        }
        public static void Alarm(int kalancan)
        {
            Console.WriteLine("Alarm! Canınız azalıyor.");
        }
        public static void Uyari(int kalancan)
        {
            Console.WriteLine("Uyarı! Kalan can:{0}",kalancan);
        }
    }
}
