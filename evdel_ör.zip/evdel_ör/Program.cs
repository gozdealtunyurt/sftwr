﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace evdel_ör
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("can miktarını girin, eğer default olarak atansın istiyorsanız enter tuşuna basınız.");
            int girlncn = Convert.ToInt32(Console.ReadLine());
            if (Console.ReadKey().Key != ConsoleKey.Enter)
            {
                girlncn = 100;
            }
            denemee dene = new denemee(girlncn);
            dene.Eventdeniyoruz += Uyari;
            dene.Eventdeniyoruz += Dikkat;
            dene.oyunabasla();
            dene.oyunabasla();
            dene.oyunabasla();
            dene.oyunabasla();
            dene.oyunabasla();
            dene.oyunabasla();
            dene.oyunabasla();
            dene.oyunabasla();
            dene.oyunabasla();
            dene.oyunabasla();
            dene.oyunabasla();
            dene.oyunabasla();
            Console.ReadLine();
        }
        public static void Uyari()
        {
            Console.WriteLine("canınız bitmek üzere 40 altına iniyor, kalan can  miktarı: {0}");
        }
        public static void Dikkat()
        {
            Console.WriteLine("can bitmek üzere.");
        }
    }
}
