﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace evdel_ör
{
    public class denemee
    {
        public delegate void Delegatedeniyoruz();
        public event Delegatedeniyoruz Eventdeniyoruz;
        private int _can = 100;
        public int can
        {
            get
            {
                return _can;
            }
            set
            {
                _can = value;
            }
        }
        public denemee(int girilencanmiktarı)
        {
            _can = girilencanmiktarı;
        }
        public denemee()
        {
           
            
        }
        public void oyunabasla()
        {
            can = can - 10;
            Console.WriteLine("can: " + can);
            if (can <= 40)
                Eventdeniyoruz();
            else if (can == 0)
            {
                Console.WriteLine("canınız bitti.");
               
            }
        }
    }
}
