﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace deenme
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("boşluk sayısını öğrenmek istediğiniz cümleyi giriniz: ");
            string cümle = Console.ReadLine();
            int bosluksaysayac = 0;
            for (int i = 0; i < cümle.Length; i++)
            {
                if (cümle[i] == ' ')

                    bosluksaysayac++;

            }
            Console.WriteLine($"cümlenizde {bosluksaysayac} kadar boşluk vardır.");
            Console.ReadLine();
        }
    }
}
