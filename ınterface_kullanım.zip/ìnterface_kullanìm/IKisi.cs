﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ınterface_kullanım
{
    interface IKisi
    {
        string AdSoyad { get; set; }
        string Adres { get; set; }
        void Bilgi();
    }
}
