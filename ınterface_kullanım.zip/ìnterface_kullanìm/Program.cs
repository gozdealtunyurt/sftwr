﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ınterface_kullanım
{
    public class Program
    {
        static void Main(string[] args)
        {
            IKisi isci = new Isci();
            Isci i1 = new Isci();
            i1.AdSoyad = "Gözde A";
            i1.Adres = "Ankara";
            isci.Bilgi();
            i1.Calis();
            // burada biz adsoyad ve adres bilgilerini ilk önce isci nesnesinden örneklediğim zaman bilgi metodu eksik çalıştı galiba onları görmedi çünkü
            //ben calıs metodunu başka bir nesneden örnekledim. Buna dikkat.
            Yonetici y1 = new Yonetici();
            y1.AdSoyad = "Özlem A";
            y1.Adres = "Çorum";
            y1.Bilgi();
            y1.Denetle();
            Console.ReadLine();
        }
    }
}
