﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ınterface_kullanım
{
    public class Yonetici : IKisi
    {
        public string AdSoyad { get; set; }
        public string Adres { get; set; }
        public void Bilgi()
        {
            Console.WriteLine("yönetici classındaki bilgi metodu çalıştı.");
        }
        public void Denetle()
        {
            Console.WriteLine("yönetici classındaki denetle metodu çalıştı, ad-soyad ({0}) ve adres({1}) bilgileri girildi.", AdSoyad, Adres);
        }
    }
}
