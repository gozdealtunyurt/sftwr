﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ınterface_kullanım
{
    public class Isci:IKisi
    {
        public string AdSoyad { set; get; }
        public string Adres { set; get; }
        public void Bilgi()
        {
            Console.WriteLine("isci classındaki bilgi metodu çalıştı.");
        }
        public void Calis()
        {
            Console.WriteLine("isci classındaki calis metodu çalıştı, ad-soyad ({0}) ve adres({1}) bilgileri girildi.",AdSoyad,Adres);
        }
    }
}
