﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace delegate_events
{
    class DelegateTestApp
    {
        public DelegateTestApp()
        {
            testDelegate d = new testDelegate(ok);
            d += ok2;
            d += ok3;
            string i = Console.ReadLine();
            d(Convert.ToInt32(i));
        }
        public delegate void testDelegate(int a);
        public void ok(int i)
        {
            Console.WriteLine($"{i} girdiniz");
        }
        public void ok2(int i)
        {
            Console.WriteLine($"{i} emin misiniz");
        }
        public void ok3(int i)
        {
            Console.WriteLine($"{i} son kez doğru mudur");
        }
    }
    class Program
    {
        public static void Main(string[] args)
        {
            new DelegateTestApp();
            Console.ReadLine();
        }
    }
}








