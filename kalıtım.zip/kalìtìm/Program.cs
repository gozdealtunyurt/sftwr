﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kalıtım
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bilgisayar B1=new bilgisayar();
            //B1.id = 1;
            B1.marka = "lenova";
            B1.model = "z50";
            B1.islemci = "i5";
            B1.alisfiyat = 1500M;
            B1.satisfiyat = 1600M;
            B1.kampanyafiyat = 1000M;
            B1.barkod = "1234567890";
            sanaldatebase.yeniurunekle(B1);//baseclasstan bir nesne kabul ederim.içinde b1 yazmadan önce data yazıyordu yani bizden data grişi istiyr.bilgisayardan b1 tüemişti
            //sstatic metoto biziim vermiş olduğumuz nesenye göre çalışır ve içeride tutmuş old hemde private olan arrayliste bu değeri basar.
        }
    }
}
