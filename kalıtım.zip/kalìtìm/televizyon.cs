﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kalıtım
{
    public class televizyon:urun
    {
        public bool smartTv { get; set; }
        public bool HDMI { get; set; }
        public string ekranboyutu { get; set; }
    }
}
