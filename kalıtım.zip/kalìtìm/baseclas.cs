﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kalıtım
{
    public class baseclas
    {

        public static int sayac = 1;
        public baseclas()
        {
            _id = sayac;
            sayac++;
        }
        private int _id;
        public int id
        {
            get
            {
                return _id;
            }
            private set
            {
                //_id = sayac;
                //sayac++;
            }
        }
        private string _barkod;
        public string barkod {
            get
            {
                return _barkod;
            }
            set 
            {
                //bool kontrolislemi=sanaldatabase.dbBarkodkodKontrol(value);   bu dieğr yolla yapılan
                //if (!kontrolislemi) {_barkod=value;}değeri saanal database içinde bulamadm
                //else yapar cw ile sanal database içine bu barkod değeri daha önceden girilmiştir
            }
        }
        public DateTime olusturmaTarih { get; set; }
        public int olusturulankullanici { get; set; }
        public DateTime guncellemeTarih { get; set; }
        public int guncelleyenKullanici { get; set; }
        public bool silindi { get; set; }
    }
}
