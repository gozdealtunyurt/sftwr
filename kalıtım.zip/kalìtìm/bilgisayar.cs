﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kalıtım
{
    public class bilgisayar:urun
    {
        public string islemci { get; set; }
        public string ram { get; set; }
        public string ekrankarti { get; set; }

    }
}
