﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kalıtım
{
    public static class sanaldatebase
    {
        private static ArrayList db = new ArrayList();

        //array list obje alır!!!!
        public static void yeniurunekle(baseclas data)//base clastan türeyen dataları buraya topla ve hepsin buaraya al
        {
            //database içinde beneim ekelmek istediğim barkod var ise array list içersiine bunu ekleme 
            //data null değilse ve datanın içerisnde bulunana değr null değilse "string old için özel bir fonk vardır onunla kontrol edilebilir."
            //daha sonra bunu kontrol ettikten sonra array içine datayı ekliyoruz ama datayıe klerken kontorl ettikten sonra yani
            // biz array listi örnkelemden bunu yapamayız o yüzden önce arrayden bir öenkelmee yapammaız egrekri
            //örneklemek için bir tane static yapıcı metota ihtiaycımız var.
            if (data != null && !string.IsNullOrEmpty(data.barkod))
            {
                db.Add(data);
            }
        }
        //str olarak ıdşarıdan gelen barkod parametrelesini kabl et
        public static bool dbbarkodkontrol(string barkod)
        {
            //bool kontrollistesi = false;
            if (db != null && db.Count > 0)
            {
                for(int i = 0; i < db.Count; i++)
                {
                    baseclas bc=(baseclas)db[i];//baseclas içinde barkod değerim var.obj deki deeğri baseclasa çevirdim
                    if(bc.barkod == barkod)
                    {
                        return true;//girerse ture döner // buulursam tur döner başka bir yolla:
                        //kontrolislemi=true;
                    }
                }
            }
            return false;//girmezse eeğr yanlış döner.buraya şu da yazılabilir:
            //return kontrolislemi;
        }
    }
}
