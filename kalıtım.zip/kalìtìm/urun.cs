﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kalıtım
{
    public class urun : baseclas
    {
        public string marka { get; set; }
        public string model { get; set; }
        private decimal _alisfiyat;
        public decimal alisfiyat
        {
            get
            {
                return _alisfiyat;
            }
            set
            {

                if (value > 0)
                {
                    Console.WriteLine("uygun bir sayı girdiniz.");
                    _alisfiyat = value;
                }
                else
                {
                    Console.WriteLine("doğru sayıyı giriniz.");
                }
            }
        }
        private decimal _satisfiyat;
        public decimal satisfiyat
        {
            get
            {
                return _satisfiyat;
            }
            set
            {
                if (value > alisfiyat)
                {
                    Console.WriteLine("doğru giriş.");
                    _alisfiyat = value;
                }
                else
                {
                    Console.WriteLine("hatalı giriş yapıldı.");
                }
            }
        }
        private decimal _kampanyafiyat;
        public decimal kampanyafiyat
        {
            get
            {
                return _kampanyafiyat;
            }
            set
            {
                if (value > 0)
                {
                    Console.WriteLine("doğru giriş.");
                    _kampanyafiyat = value;
                }
                else
                {
                    Console.WriteLine("yanlış giriş yapıldı.");
                }
            }
        }
    }
}
