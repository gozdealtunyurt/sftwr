﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace metot_calismaa
{
    public class metotclas
    {
        //public void topla(int sayi1, int sayi2)
        //{
        //    int sonuc = sayi1 + sayi2;
        //    Console.WriteLine(sonuc);
        //}
        //public int toplaa(int sayi1, int sayi2)
        //{
        //    return sayi1 + sayi2;
            
        //}



    }
}
