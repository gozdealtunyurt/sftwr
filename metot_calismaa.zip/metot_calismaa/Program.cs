﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace metot_calismaa
{

    public class Program
    {
        static void Main(string[] args)
        {
            //metotclas nesne = new metotclas();
            //nesne.topla(4, 6);
            //Console.WriteLine(nesne.toplaa(14, 6));
            //Console.ReadLine();


        }
    }
}
