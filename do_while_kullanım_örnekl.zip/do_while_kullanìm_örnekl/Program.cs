﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace do_while_kullanım_örnekl
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int deger;
            int sifre = 20032009;
            do
            {
                Console.WriteLine("şifreyi giriniz: ");
                int girilensifre = Convert.ToInt32(Console.ReadLine());
                deger = girilensifre;
            }
            while (deger != sifre);
            Console.WriteLine("tebriks");
            Console.ReadLine();
        }
    }
}
