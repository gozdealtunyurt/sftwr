﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ufakbirmetodkullanım_örnegi
{
    public class metodclass
    {
        public static void yashesapla(int dogumyili)
        {
            int sonuc = DateTime.Now.Year - dogumyili;
            Console.WriteLine("yaşınız: "+sonuc);
        }
        public static int arametod()
        {
            int girilenyil = Convert.ToInt32(Console.ReadLine());
            return girilenyil;
        }
    }
}
