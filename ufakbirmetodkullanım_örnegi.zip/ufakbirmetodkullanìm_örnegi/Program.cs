﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ufakbirmetodkullanım_örnegi
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("hesaplamak istediğiniz yaş için doğum yılınıız giriniz: ");
            int girilenyil = metodclass.arametod();
            Console.WriteLine("hesaplanıyor...");
            System.Threading.Thread.Sleep(3000);
            Console.WriteLine("hesaplanıyor,biraz daha bekleyiniz...");
            System.Threading.Thread.Sleep(3000);
            metodclass.yashesapla(girilenyil);
            Console.ReadLine();
        }
    }
}
