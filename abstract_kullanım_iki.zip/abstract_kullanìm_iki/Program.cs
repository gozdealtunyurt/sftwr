﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace abstract_kullanım_iki
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("karenin kenraını giirniz: ");
            int karekenar=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("dikdörtgenin uzun kenraını giirniz: ");
            int drtgnuzunkenar = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("dikdörtgenin kısa kenraını giirniz: ");
            int drtgenkısakenar = Convert.ToInt32(Console.ReadLine());

            Dortgen drtgen = new Dikdortgen(drtgnuzunkenar, drtgenkısakenar);
            drtgen.AlanHesapla();

            //Dortgen kre = new Kare(karekenar);
            Kare kr = new Kare(karekenar);
            //kre.AlanHesapla();
            kr.AlanHesapla();
            Console.ReadLine();
        }
    }
}
