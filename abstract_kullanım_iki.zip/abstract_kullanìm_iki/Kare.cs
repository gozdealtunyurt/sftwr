﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace abstract_kullanım_iki
{
    public class Kare:Dortgen
    {
        public Kare(int a):base(a,a)
        {

        }
        public override void AlanHesapla()
        {
            int sonuc2 = A * A;
            Console.WriteLine("Karenin alanı: "+sonuc2);
        }
        public void deneme()
        {
            Console.WriteLine("deneme çalışıyor mu?");
        }
    }
}
