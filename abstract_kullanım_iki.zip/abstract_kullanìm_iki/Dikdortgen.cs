﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace abstract_kullanım_iki
{
    public class Dikdortgen:Dortgen
    {
        public Dikdortgen(int a,int b) : base(a, b)
        {
            
        }
        public override void AlanHesapla()
        {
            int sonuc = A * B;
            Console.WriteLine("dikdörtgenin alanı: "+sonuc);
        }
    }
}
