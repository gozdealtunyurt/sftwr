﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace abstract_kullanım_iki
{
    public abstract class Dortgen
    {
        protected int A { get; set; }
        protected int B {  get; set; }
        public Dortgen(int a,int b)
        {
            A= a;
            B= b;
        }
        public abstract void AlanHesapla();
    }
}
