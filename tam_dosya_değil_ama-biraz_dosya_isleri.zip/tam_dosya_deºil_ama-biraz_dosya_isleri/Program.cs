﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tam_dosya_değil_ama_biraz_dosya_isleri
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string diziyolu = @"C:\Users\Gözde\OneDrive\Masaüstü\YAZILIM\3. DÖNEM\SEÇMELİLER";
            string[] dosyaadlari = Directory.GetFiles(diziyolu);
            Console.WriteLine("dosya içinde {0} adet dosyanız bulunmaktadır." ,diziyolu.Length);
            foreach (string dosyaadi in dosyaadlari)
            {
                
                    Console.WriteLine(dosyaadi);
                
            }
            Console.WriteLine("aratmak istediğiniz bir dizin yolu ismi varsa lütfen str olarak buraya giriniz: ");
            string aranacakdosyaadi = Console.ReadLine();
            for (int i = 0; i <= dosyaadlari.Length; i++)
            {
                if (dosyaadlari[i] == aranacakdosyaadi)
                {
                    Console.WriteLine("aradığınız dosya adı: "+ aranacakdosyaadi);
                    Console.WriteLine("dosyanız sıradadır: "+ i + 1);
                }
                else
                {
                    Console.WriteLine("öyle bir dosya bu diizn içerisinde bulunamadı.");
                }
            }
            Console.WriteLine("başka bir dizin içerisinde kaç adet aynı formatta dizin olduğunu saydırma işlemi, dosyamız sayısal tasarım dersi.");
            string dizinyolu2 = @"C:\Users\Gözde\OneDrive\Masaüstü\YAZILIM\3. DÖNEM\SAYISAL TASARIM";
            string[] dosyaadlari2 = Directory.GetFiles(dizinyolu2);
            Console.WriteLine("formatı giriniz: ");
            string uzanti = "*.txt";
            string[] dosyaadlari1 = Directory.GetFiles(dizinyolu2, uzanti);
            int toplam = 0;
            foreach (string dosyaadi1 in dosyaadlari1)
            {
                toplam = toplam + 1;
            }
            Console.WriteLine("toplam dizin sayısı: " + toplam);
            Console.ReadLine();
        }
    }
}
