﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace null_nasıl_kullanılır
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //değişken tanımlandı ama ona değer atanmadı.Veritabanından değer alırken veri yoksa null döner.
            Nullable<int>sayi= null;
            int?sayi2= null;
            string deger = null;
        }
    }
}
