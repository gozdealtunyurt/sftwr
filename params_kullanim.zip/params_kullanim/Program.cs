﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace params_kullanim
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //bir dizi gibi yapıyordu
            topla(1, 3, 5, 67, 89, 54);
            void topla(params int[] nums)
            {
                int toplam = 0;
                for (int i = 0; i < nums.Length; i++)
                {
                    toplam += nums[i];
                }
                Console.WriteLine(toplam);
                Console.ReadLine();
            }
        }
    }
}
