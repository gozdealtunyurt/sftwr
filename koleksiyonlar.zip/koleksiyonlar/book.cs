﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace koleksiyonlar
{
    public class book
    {
        public string kitapadı { get; set; }
        public string yazaradı { get; set; }
        public int yayınyılı { get; set; }
        public override string ToString()
        {
            return $"Kitap Adı: {kitapadı}, Yazar Adı: {yazaradı}, Yayın Yılı: {yayınyılı}";
        }
    }
}
