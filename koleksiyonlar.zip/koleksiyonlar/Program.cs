﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace koleksiyonlar
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //ArrayList A1 = new ArrayList();
            //ArrayList A2 = new ArrayList();
            //A1.Add(12);
            //A1.Add(54);
            //A1.Add(3);
            //A1.Add(32);
            //A1.Add(43);
            //A1.Add(75);
            //A1.Add(31);
            //A1.Add(9);
            //A1.Add(35);
            //A1.Add(34);
            //A1.Add(545);
            //A1.Add(76);
            //A1.Add(89);
            //Console.WriteLine(A1[2]);
            //A1[2] = 32;
            //Console.WriteLine(A1[2]);
            //int a = A1.Capacity;
            //Console.WriteLine(a);
            //Object O1 = A1[2];
            //Console.WriteLine(O1);
            //A1.Remove(3);

            //Console.WriteLine("eleman giriniz.");
            //int girilen=Convert.ToInt32(Console.ReadLine());
            //A1.Add(girilen);
            //A1.Sort();
            //foreach (int i in A1)
            //{
            //    Console.WriteLine(i);
            //}

            //*******************************************************************************************************

            //List<int> list = new List<int>();
            //list.Add(1);

            //List<mustericlass> list1 = new List<mustericlass>();
            //list1.Add(new mustericlass()
            //{
            //    yas = 12,
            //    ad="gözde",
            //    soyad="altunyurt",
            //    cinsiyet='k',
            //});

            List<book> list = new List<book>();
            list.Add(new book()
            {
                kitapadı = "Vadideki Zambak",
                yazaradı = "Balzac",
                yayınyılı = 2018,
            });
            list.Add(new book()
            {
                kitapadı = "Dede Korkut Hikayeleri",
                yazaradı = "anonim",
                yayınyılı = 2013,
            });
            list.Add(new book()
            {
                kitapadı = "Böyle Söyledi Zerdüşt",
                yazaradı = "Freıuedrıch",
                yayınyılı = 2014,
            });
            list.Add(new book()
            {
                kitapadı = "Suç ve Ceza",
                yazaradı = "Dostoyevski",
                yayınyılı = 1992,
            });
            list.Add(new book()
            {
                kitapadı = "Gurur ve Önyargı",
                yazaradı = "Austen",
                yayınyılı = 2003,
            });
            list.Add(new book()
            {
                kitapadı = "Genç Weatherin Acıları",
                yazaradı = "Gothe",
                yayınyılı = 2021,
            });
            Console.WriteLine("*****************************************DİJİTAL KÜTÜPHANEYE HOŞ GELDİNİZ*****************************************");
            Console.WriteLine("eger kitapları listeletmek istiyorsanız 1'e basınız.");
            Console.WriteLine("eger kitaplara ekleme yapmak istiyorsanız 2'ye basınız.");
            Console.WriteLine("eger kitaplardan silme yapmak istiyorsanız 3'e basınız.");
            Console.WriteLine("eger çıkış yapmak istiyorsanız 4'e basınız.");
            int girilen = Convert.ToInt32(Console.ReadLine());
            switch (girilen)
            {
                case 1:
                    foreach (var book in list)
                    {
                        Console.WriteLine(book);
                        Console.WriteLine();
                    }
                    break;
                case 2:
                    Console.WriteLine("ekleme yapmak istediğiniz kitabın adını giriniz: ");
                    string girilenkitapadı = Console.ReadLine();
                    Console.WriteLine("ekleme yapmak istediğiniz kitabın yazarının adını giriniz: ");
                    string girilenyazardı = Console.ReadLine();
                    Console.WriteLine("ekleme yapmak istediğiniz kitabın basım yılını giriniz: ");
                    int girilenbasımyılı = Convert.ToInt32(Console.ReadLine());
                    book yeniKitap = new book()
                    {
                        kitapadı = girilenkitapadı,
                        yazaradı = girilenyazardı,
                        yayınyılı = girilenbasımyılı,
                    };

                    list.Add(yeniKitap);
                    //list.Add(new book()
                    //{
                    //    kitapadı = girilenkitapadı,
                    //    yazaradı = girilenyazardı,
                    //    yayınyılı = girilenbasımyılı,
                    //});
                    Console.WriteLine($"Kitap başarıyla eklenmiştir:\n{yeniKitap}");
                    break;
                case 3:
                    Console.WriteLine("silmek istediğiniz kitabın adını giriniz: ");
                    string silinecekKitapAdi = Console.ReadLine();
                    book silinecekKitap = null;
                    foreach (var kitap in list)
                    {
                        if (kitap.kitapadı == silinecekKitapAdi)
                        {
                            silinecekKitap = kitap;
                            break;
                        }
                    }

                    if (silinecekKitap != null)
                    {
                        list.Remove(silinecekKitap);
                        Console.WriteLine($"{silinecekKitapAdi} isimli kitap başarıyla silindi.");
                    }
                    else
                    {
                        Console.WriteLine($"{silinecekKitapAdi} isimli kitap bulunamadı.");
                    }
                    break;
                case 4:
                    Console.WriteLine("Çıkış yapılıyor. İyi günler!");
                    return; // Main metodu içinde bulunduğu için return kullanarak programı sonlandırabilirsiniz.Break kullanılmaz.
                default:
                    Console.WriteLine("doğru tuşlama yapınız, lütfen.");
                    break;
            }
            Console.ReadLine();


        }
    }
}
