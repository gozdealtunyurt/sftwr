﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace unutma
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("isminiz nedir?");
            //string isim=Console.ReadLine();
            //Console.WriteLine(isim);
            //Console.ReadLine();
            int[] liste=new int[10] ;
            liste =new int[] { 3,543,32};
            for(int i=0;i<liste.Length;i++)
            {

            }

        }
    }
}
