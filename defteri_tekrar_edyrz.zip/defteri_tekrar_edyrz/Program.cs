﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace defteri_tekrar_edyrz
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] dizisayi = { 54, 8, 21, 9, 76, 40, 32, 95 };
            string[] diziisim = new string[10];
            for (int i = 0; i < diziisim.Length; i++)
            {
                Console.WriteLine($"{i + 1}.elemanın dizi değerini giriniz: ");
                string alinaneleman = Console.ReadLine();
                diziisim[i] = alinaneleman;
            }
            foreach (int elemanint in dizisayi)
            {
                Console.WriteLine(elemanint);
            }
            foreach (string elemanstr in diziisim)
            {
                Console.WriteLine(elemanstr);
            }
            Console.ReadLine();
        }
    }
}
