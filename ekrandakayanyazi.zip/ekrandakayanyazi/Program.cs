﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ekrandakayanyazi
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Clear();
            for (int a = 0; a < 15; a++)
            {
                Console.SetCursorPosition(a, 15);
                Console.Write("Hi World!");
                System.Threading.Thread.Sleep(2);
                Console.Clear();
            }
        }
    }
}
