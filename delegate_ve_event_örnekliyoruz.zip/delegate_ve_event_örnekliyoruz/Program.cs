﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace delegate_ve_event_örnekliyoruz
{
    public delegate int MathDelegate(int a, int b);
    public class Program
    {
        static MathDelegate mathD;
        static void Main(string[] args)
        {
            mathD += Carpma;
            mathD += Topla;
            int sonuc=mathD(2, 3);
            Console.WriteLine(sonuc);
            Console.ReadLine();
        }
        public static int Topla(int a,int b)
        {
            Console.WriteLine("toplam: ",(a+b));
            return a + b;
        }
        public static int Carpma(int a,int b)
        {
            Console.WriteLine("carpim: "+(a*b));
            return a * b;
        }
    }
}
