﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dictionary_yapısı
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, int> dic = new Dictionary<string, int>();
            dic["Ankara"] = 06;
            dic["İstanbul"] = 34;
            Console.WriteLine("plakasını öğrenmek istediğiniz şehrin ismini giriniz: ");
            string girilensehir = Console.ReadLine();
            Console.WriteLine(dic[girilensehir]);
            Console.ReadLine();
            //burada hatayı conosle ekranına verecek bir şey yapamdık o yüzden hata veriyor ama diğerlerinde if ya da try bloğu il bu hatayı ontrol altına albiliyoruz
        }
    }
}
