﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bir_meotta_iki_farklı_deger_döndürme
{
    public class Program
    {
        static void Main(string[] args)
        {
            //birinci kullanım
            int[] sonuclarDizi = ToplaVeCarp(3, 4);
            Console.WriteLine($"Toplam: {sonuclarDizi[0]}, Çarpım: {sonuclarDizi[1]}");
            Console.ReadLine();
            Console.WriteLine();
            //birinci kullanım
            //ikinci kullanım(Tupple ,demet, kullanımı)
            var sonuclarDemet = ToplaVeCarp2(3, 4);
            Console.WriteLine($"Toplam: {sonuclarDemet.Toplam}, Çarpım: {sonuclarDemet.Carpim}");
            Console.ReadLine();
            //ikinci kullanım
        }
        //birinci kullanım
        public static int[] ToplaVeCarp(int sayi1, int sayi2)
        {
            int toplam = sayi1 + sayi2;
            int carpim = sayi1 * sayi2;

            int[] sonuclar = { toplam, carpim };
            return sonuclar;
        }
        //birinci kullanım
        //ikinci kullanım
        public static (int Toplam, int Carpim) ToplaVeCarp2(int sayi1, int sayi2)
        {
            int toplam2 = sayi1 + sayi2;
            int carpim2 = sayi1 * sayi2;

            return (toplam2, carpim2);
        }
        //ikinci kullanım
    }
}
