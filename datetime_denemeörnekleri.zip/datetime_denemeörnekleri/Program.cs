﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace datetime_denemeörnekleri
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //DIŞARDAN ALDIĞIM ZAMANA NASIL KULLANIRIM ADLI UFAK BİR KISIM
            Console.WriteLine("doğum tarihinizi giriniz: ");
            DateTime girilentarih =Convert.ToDateTime(Console.ReadLine());//BİTİŞ
            DateTime mezuniyet = new DateTime(2003, 07, 20);
            Console.WriteLine("yılın toplam günü şu kadar: " + mezuniyet.DayOfYear);
            Console.WriteLine("yılın şu günü doğmussunuz: " + mezuniyet.DayOfWeek);
            TimeSpan sonuc = DateTime.Now - mezuniyet;//bu tarihleri toplamak içinde kullanılabilir ama o zaman bunları ayrı ayrı iki değişkene atamamız gerekir.
            Console.WriteLine("şu kadar yaşınız var: " + sonuc.Days / 365);//bunun yerine sonuc.TotalDays özelliği de kullanılıyormuş.
            Console.WriteLine("şu kadar gün yaşamışsınız: " + sonuc.Days);
            Console.WriteLine("doğduğunuz günden sonraki gün: " + mezuniyet.AddDays(1));
            Console.WriteLine("doğduğunuz günden sonraki ay: " + mezuniyet.AddMonths(1));

            Console.ReadLine();

        }
    }
}
