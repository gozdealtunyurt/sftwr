﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace abstract_interface
{
    public class hesapla : abs
    {
        public int kısakenar { get; set; }
        public int uzunkenar { get; set; }

        public override void abstmetot()
        {
            int sonuc=(kısakenar + uzunkenar)*2;
            Console.WriteLine(sonuc);
        }
    }
}
