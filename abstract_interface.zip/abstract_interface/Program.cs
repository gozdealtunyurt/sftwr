﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace abstract_interface
{
    public class Program
    {
        static void Main(string[] args)
        {
            hesapla H1 = new hesapla();
            H1.baslat();
            Console.WriteLine("kısa kenarı giriniz: ");
            int grkısakenar = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("uzun kenarı giriniz: ");
            int gruzunkenar = Convert.ToInt32(Console.ReadLine());
            H1.kısakenar = grkısakenar;
            H1.uzunkenar = gruzunkenar;
            H1.abstmetot();
            Console.ReadLine();
        }
    }
}
