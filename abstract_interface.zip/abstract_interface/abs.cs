﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace abstract_interface
{
    public abstract class abs
    {
        public void baslat()
        {
            Console.WriteLine("abs normal metot çalıştı.");
        }
        public abstract void abstmetot();

    }
}
