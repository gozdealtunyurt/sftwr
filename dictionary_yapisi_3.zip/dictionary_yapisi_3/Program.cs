﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dictionary_yapisi_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, int> dic = new Dictionary<string, int>();
            dic["Ankara"] = 06;
            dic["İstanbul"] = 34;

            Console.WriteLine("Plakasını öğrenmek istediğiniz şehrin ismini giriniz: ");
            string cityName = Console.ReadLine();

            if (dic.ContainsKey(cityName))
            {
                int plateNumber = dic[cityName];
                Console.WriteLine($"{cityName} şehrinin plakası: {plateNumber}");
            }
            else
            {
                Console.WriteLine($"{cityName} şehri bulunamadı.");
            }
            Console.ReadLine();
        }
    }
}
