﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ref_out_kullanım
{
    public class Program
    {

        static void Main(string[] args)
        {
            int sayi = 10;
            deneme(ref sayi);
            Console.WriteLine(sayi);
            int sayi2 = 20;
            deneme2(sayi2);
            Console.WriteLine(sayi2);
            Console.ReadLine();
            //int value2;
            //Initialize(out value2);
            //Console.WriteLine(value2);
            Console.ReadLine();
        }
        public static void deneme(ref int denemesayi)
        {
            denemesayi = 15;
        }
        public static void deneme2(int denemesayi2)
        {
            denemesayi2 = 25;
        }
        //static void Initialize(out int number)
        //{
        //    number = 0;
        //}

    }
}
