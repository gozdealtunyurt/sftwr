﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace get__set_kapsulation_kullanım
{
    public class Program
    {
        static void Main(string[] args)
        {
            ogrenci deneme= new ogrenci();
            Console.WriteLine("tc no giriniz: ");
            int girilentc = Convert.ToInt32(Console.ReadLine());
            deneme._tcno = girilentc;
            Console.WriteLine(deneme._tcno);
           
            Console.ReadLine();

        }
    }
}
