﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace get__set_kapsulation_kullanım
{
    public class ogrenci
    {
        private int tcno = 12345;
        public int _tcno {
            get
            {
                return tcno;
            }
            set
            {
                tcno = value;
            }
        }

    }
}
