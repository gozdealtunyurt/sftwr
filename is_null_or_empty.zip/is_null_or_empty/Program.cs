﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace is_null_or_empty
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("bir metin giriniz: ");
            string metin = Console.ReadLine();
            if (string.IsNullOrEmpty(metin))
            {
                Console.WriteLine("metin boş veya null.");
            }
            else
            {
                Console.WriteLine("metin: " + metin);
            }
            Console.ReadLine();
        }
    }
}
