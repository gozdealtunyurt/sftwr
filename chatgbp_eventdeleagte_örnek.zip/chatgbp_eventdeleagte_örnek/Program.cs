﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chatgbp_eventdeleagte_örnek
{
    public class Program
    {
        static void Main(string[] args)
        {
            BankaHesabi hesap = new BankaHesabi();
            hesap.bakdeg += hesapgüncelle;
            hesap.bakdeg += hesapgüncelle2;
            hesap.HesapSahibi("Ahmet");
            hesap.HesapBakiyesi(1000);
            hesap.BakiyeGuncelle(1000);
            Console.ReadLine();
        }
        public static void hesapgüncelle(int bakiye)
        {
            Console.WriteLine("eklemek istediğiniz para miktarını giriniz: ");
            int girilenpara = Convert.ToInt32(Console.ReadLine());
            bakiye = bakiye + girilenpara;
            Console.WriteLine(bakiye);
            Console.WriteLine("bakiyeniaz güncellendi.");
        }
        public static void hesapgüncelle2(int bakiye)
        {
            Console.WriteLine("çekmek istediğiniz para miktarını giriniz: ");
            int girilenpara = Convert.ToInt32(Console.ReadLine());
            bakiye = bakiye - girilenpara;
            Console.WriteLine(bakiye);
            Console.WriteLine("bakiyeniz güncellendi.");
        }

    }
}
