﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chatgbp_eventdeleagte_örnek
{
    public class BankaHesabi
    {
        public delegate void BakiyeDegisti(int bakiye);
        public event BakiyeDegisti bakdeg;
        private int hespbk;

        public void HesapBakiyesi(int bakiye)
        {
            hespbk=bakiye;
            Console.WriteLine("bakiyeniz: "+bakiye);
        }
        public void HesapSahibi(string sahip)
        {
            Console.WriteLine("adınız: "+sahip);
        }
        public void BakiyeGuncelle(int yenibakiye)
        {
            bakdeg(yenibakiye);
        }

    }
}
