﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dictionary_yapısı_4
{
    public class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> dic = new Dictionary<string, string>()
            {
                { "34 plaka nerenindir", "İstanbul"},
                {"06 nerenşn plakasıdır","Ankara"}
            };
            int sayc = 0;
            foreach (var soru in dic)
            {
                Console.WriteLine(soru.Key);
                string cevap = Console.ReadLine();
                //if içinde girilen değerin büyüklük küçüklük durumu sıkıntı olmasın diye girilen değeri ve kedni yazdığım değerin harflerini küçük yapıp eşitledim ve böylelikle aynı olmuş oldu.
                if (cevap.ToLower() == soru.Value.ToLower())
                {
                    sayc++;
                }
                Console.WriteLine(sayc);
                Console.ReadLine();
            }
        }
    }
}
