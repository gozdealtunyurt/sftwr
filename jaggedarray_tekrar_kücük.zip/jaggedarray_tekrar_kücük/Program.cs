﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jaggedarray_tekrar_kücük
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //bir dizi içinde farklı uzunluklara sahip başka diziler içeren bir dizidir
            Console.Title = "jagged_dizi_calisma";
            int[][] jaggeddizi = new int[3][];

            int[] dizi1 = new int[3];
            int[] dizi2 = { 3, 5, 7, 8, 9 };
            int[] dizi3 = { 2, 4, 6 };

            Console.WriteLine("diziyi doldurun: ");
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine($"dizinin {i + 1}.elemanı: ");
                int alınaneleman = Convert.ToInt32(Console.ReadLine());
                dizi1[i] = alınaneleman;
            }
            foreach (int i in dizi1)
            {
                Console.WriteLine(i);
            }
            jaggeddizi[0] = dizi1;
            jaggeddizi[1] = dizi2;
            jaggeddizi[2] = dizi3;

            Console.WriteLine(jaggeddizi[0][2]);
            Console.WriteLine(jaggeddizi[1][2]);
            Console.ReadLine();
        }
    }
}
