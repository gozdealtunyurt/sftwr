﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sanal_metot_kullanım
{
    public class denekiki : denekbir
    {
        public denekiki()
        {
            Console.WriteLine("denekiki classının yapıcı metotu çalıştı.");
        }
        public override void sanalmetot()
        {
            base.sanalmetot();
            Console.WriteLine("denekiki classında override edilen virtual metot çalıştı.");
        }
    }
}
