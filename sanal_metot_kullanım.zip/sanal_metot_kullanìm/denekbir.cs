﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sanal_metot_kullanım
{
    public class denekbir
    {
        public denekbir()
        {
            Console.WriteLine("denekbir classının yapıcı metotu çalıştı.");
        }
        public virtual void sanalmetot()
        {
            Console.WriteLine("denekbir classının virtual kısmı çalıştı.");
        }

    }
}
