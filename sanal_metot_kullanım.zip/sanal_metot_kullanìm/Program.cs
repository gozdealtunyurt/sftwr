﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sanal_metot_kullanım
{
    public class Program
    {
        static void Main(string[] args)
        {
            //denekbir d1 = new denekbir();
            //d1.sanalmetot();
            denekiki d2 = new denekiki();
            d2.sanalmetot();
            Console.ReadLine();
        }
    }
}
