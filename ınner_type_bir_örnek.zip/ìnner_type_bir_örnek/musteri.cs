﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ınner_type_bir_örnek
{
    public class musteri
    {
        public string isim;
        public int no;
        public char cinsiyet;
        public musteriadres[] musteriadresleri;
    }
}
