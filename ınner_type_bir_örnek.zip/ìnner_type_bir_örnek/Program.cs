﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ınner_type_bir_örnek
{
    public class Program
    {
        static void Main(string[] args)
        {
            // 100 müşteriyi temsil eden bir dizi oluştur
            musteri[] musteriler = new musteri[100];

            // Örnek olarak bazı müşterilere bilgileri atayalım
            for (int i = 0; i < 100; i++)
            {
                musteriler[i] = new musteri();
                musteriler[i].cinsiyet = (i % 2 == 0) ? 'k' : 'e';
                musteriler[i].isim = $"Kişi {i + 1}";
                musteriler[i].no = 10000 + i;
                musteriler[i].musteriadresleri = new musteriadres[1];
                musteriler[i].musteriadresleri[0] = new musteriadres()
                {
                    ilçe = $"İlçe {i + 1}",
                    il = $"İl {i + 1}",
                };
            }

            // Bilgileri yazdır
            for (int i = 0; i < 100; i++)
            {
                Console.WriteLine($"{i + 1}. Müşteri Bilgileri:");
                Console.WriteLine($"İsim: {musteriler[i].isim}");
                Console.WriteLine($"No: {musteriler[i].no}");
                Console.WriteLine($"Cinsiyet: {musteriler[i].cinsiyet}");

                Console.WriteLine("\nAdres Bilgileri:");
                foreach (var adres in musteriler[i].musteriadresleri)
                {
                    Console.WriteLine($"İlçe: {adres.ilçe}");
                    Console.WriteLine($"İl: {adres.il}");
                }

                Console.WriteLine("\n------------------------\n");
            }
            Console.ReadLine();
        }
    }
}
