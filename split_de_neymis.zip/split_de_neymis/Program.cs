﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace split_de_neymis
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("bir metin giriniz: ");
            string metin = Console.ReadLine();
            string[] parcalar = metin.Split(' ');
            Console.WriteLine("boşluk sayısı: " + (parcalar.Length - 1));
            Console.ReadLine();
        }
    }
}
