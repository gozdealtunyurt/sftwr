﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ınner_type_kullanım
{
    public class adresler
    {
        public string ülke;
        public string il;
        public string ilçe;
        public char konum;
    }
}
