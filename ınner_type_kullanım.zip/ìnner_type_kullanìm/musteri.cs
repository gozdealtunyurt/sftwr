﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ınner_type_kullanım
{
    public class musteri
    {
        public string ad;
        public string soyad;
        public int telno;
        public char cinsiyet;
        public adresler[] yeniadresler;
    }
}
