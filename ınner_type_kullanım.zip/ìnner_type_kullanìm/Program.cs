﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ınner_type_kullanım
{
    public class Program
    {
        static void Main(string[] args)
        {
            musteri m1 = new musteri();
            adresler a1 = new adresler()
            {
                ülke = "türkiye",
                il = "balıkesir",
                ilçe = "bandırma",
                konum = 'y'
            };

            m1.ad = "gözde";
            m1.soyad = "altunyurt";
            m1.cinsiyet = 'k';
            m1.telno = 1234567890;
            

            m1.yeniadresler = new adresler[1];
            m1.yeniadresler[0] = a1;
            Console.WriteLine(m1.ad);
            Console.WriteLine(m1.soyad);
            Console.WriteLine(m1.cinsiyet);
            Console.WriteLine(m1.telno);
            Console.WriteLine("*******************************************");
            foreach (var x in m1.yeniadresler)
            {
                Console.WriteLine(x.ülke);
                Console.WriteLine(x.il);
                Console.WriteLine(x.ilçe);
                Console.WriteLine(x.konum);
            }
            Console.ReadLine();
        }
    }
}
