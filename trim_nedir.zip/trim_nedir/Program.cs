﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace trim_nedir
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("bir metin giriniz: ");
            string metin = Console.ReadLine();
            string temizlenenmetin = metin.Trim();
            Console.WriteLine(temizlenenmetin);
            Console.ReadLine();
        }
    }
}
