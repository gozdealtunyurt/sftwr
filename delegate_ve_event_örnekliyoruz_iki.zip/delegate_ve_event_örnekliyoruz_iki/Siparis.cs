﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace delegate_ve_event_örnekliyoruz_iki
{
    public class Siparis
    {
        public delegate void SiparisDelegate();
        public event SiparisDelegate SiparisEvent;

        public void Durum()
        {
            Console.WriteLine("siparişiniz alındı.");
            SiparisEvent();
        }
    }
}
