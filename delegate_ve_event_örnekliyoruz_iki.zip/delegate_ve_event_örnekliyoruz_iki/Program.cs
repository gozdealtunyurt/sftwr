﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace delegate_ve_event_örnekliyoruz_iki
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Siparis s = new Siparis();
            //sipariş eventi içine metotları ekliyoruz.
            s.SiparisEvent += SMSGonder;
            s.SiparisEvent += MailGonder;
            //siparisevent Siparic class içerisindeki durum metod içerisinde çalışıyor.
            //durum metodunu çağırırız.
            s.Durum();
        }
        public static void SMSGonder()
        {
            Console.WriteLine("SMS gönderildi.");
        }
        public static void MailGonder()
        {
            Console.WriteLine("Mail gönderildi");
        }
    }
}
