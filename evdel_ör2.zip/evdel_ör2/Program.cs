﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace evdel_ör2
{
    public class Program
    {
        static void Main(string[] args)
        {
            siparis ymksprs = new siparis();
            ymksprs.evnt += yemekal;
            ymksprs.evnt += yemekye;
            ymksprs.evnt += teslimat;

            ymksprs.yemek();
            Console.ReadLine();

        }

        public static void yemekal()
        {
            Console.WriteLine("siparişiniz işleme koyuldu, ödeme alındı.");
        }

        public static void yemekye()
        {
            Thread.Sleep(9000);
            Console.WriteLine("siparişiniz teslim edilmek üzere yola çıktı.");
        }
        public static void teslimat()
        {
            Thread.Sleep(9000);
            Console.WriteLine("siparişiniz teslim edildi.");
        }
    }
}
