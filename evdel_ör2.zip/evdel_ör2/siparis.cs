﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace evdel_ör2
{
    public class siparis
    {
        public delegate void dlgte();
        public event dlgte evnt;
        public void yemek()
        {
            Console.WriteLine("yemek siparişiniz alındı.");
            evnt();
        }
    }
}
