﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace event_delegate_örnek
{
    public class deneme
    {
        private int _can;
        public int can
        {
            get
            {
                return _can;
            }
            set
            {
                _can = value;
                
            }
        }
    }
}
