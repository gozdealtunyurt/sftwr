﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace REF_OUT_SINAV
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Personel p1 = new Personel();
            p1.ad = "Süleyman Gökhan";
            p1.soyad = "TAŞKIN";
            p1.tckn = "16161616161";
            Personel p2 = p1;
            p2.tckn = "10101010101";
            Console.WriteLine(p1.tckn);
            Console.WriteLine(p2.tckn);
            Console.ReadLine();

        }

    }
}
