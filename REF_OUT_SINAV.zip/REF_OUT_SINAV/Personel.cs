﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace REF_OUT_SINAV
{
    internal class Personel
    {
        public string ad;
        public string soyad;
        public string tckn;
    }
}
