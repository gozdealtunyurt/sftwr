﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kalvye_girisi_kontrolveegerler
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("bir tuşa basınız.");

            ConsoleKeyInfo tus = Console.ReadKey();
            Console.WriteLine("bastığınız karakter: " + tus.Key);
            if (tus.Key == ConsoleKey.Enter)
            {
                Console.WriteLine("enter tuşuna bastınız.");
            }
            else
            {
                Console.WriteLine("enter tuşuna basmadınız.");
            }
            if (tus.Key == ConsoleKey.Escape)
            {
                Console.WriteLine("esc tuşuna bastınız.");
            }
            else
            {
                Console.WriteLine("esc tuşuna basmadınız.");
            }
            Console.ReadLine();

        }
    }
}
